#include <iostream.h>
#include <string.h>

int main() 

{
	int numerator, denominator, result;
	cout <<"Enter the Numerator:";
	cin>>numerator;
	cout<<"Enter the denominator:";
	cin>>denominator;
	result = numerator/denominator;
	cout<<"\nThe result of division is:" <<result;
}

// See the output, when user enters 10 as numerator and 20 as denominator what happens.