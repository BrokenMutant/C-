//Example to operate on Objects of two Different class using friend Function

#include <iostream.h>

class B;     				// forward declaration
class A {
    private:
      int data;
    public:
      A(): data(12){ }	
      friend int func(A , B);   	//friend function Declaration
};

class B {
    private:
       int data;
    public:
       B(): data(1){ }
       friend int func(A , B); 		 //friend function Declaration
};

int func(A d1,B d2)
				/*Function func() is the friend function of both classes A and B. 
				So, the private data of both class can be accessed from this function.*/
{
   return (d1.data+d2.data);
}
void main()
    {
        A a;
        B b;
        cout<<"Data: "<<func(a,b);
    }

/* In this program, classes A and B has declared func() as a friend function. 
Thus, this function can access private data of both class. 
In this program, two objects of two different class A and B are passed as an 
argument to friend function. 
Thus, this function can access private and protected data of both class. 
Here, func() function adds private data of two objects and returns it 
to main function. */