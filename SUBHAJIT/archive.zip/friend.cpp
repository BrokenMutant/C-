/* C++ program to demonstrate the working of friend function.*/

#include <iostream.h>
class Distance
{
    private:
        int meter;
    public:
        Distance(): meter(0){ }
        friend int func(Distance);  	  //friend function
};
int func(Distance d)           		 //function definition
{
    d.meter=5;         	//accessing private data from non-member function
    return d.meter;
}
void main()
{
    Distance D;
    cout<<"Distance: "<<func(D);
    
}

// Output:	Distance: 5

//Here, friend function func() is declared inside Distance class. 
So, the private data can be accessed from this function.Though this 
example gives you what idea about the concept of friend function, 
this program doesn't give you idea about when friend function is helpful.