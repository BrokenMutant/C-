#include <iostream.h>
#include <string.h>
void main() 
{
	int numerator, denominator, result;
	cout <<"Enter the Numerator:";
	cin>>numerator;
	cout<<"Enter the denominator:";
	cin>>denominator;
	try {
		if(denominator == 0) 
		{
			throw denominator;
		}
		result = numerator/denominator;
		cout<<"\nThe result of division is:" <<result;
	}
	catch(int num) 
	{
		cout<<"You cannot enter "<<num<<" in denominator.";
	}
}